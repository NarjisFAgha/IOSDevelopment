//
//  ViewController.swift
//  Lab6
//
//  Created by user228293 on 7/8/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

