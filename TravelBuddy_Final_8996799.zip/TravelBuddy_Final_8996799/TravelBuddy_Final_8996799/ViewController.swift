//
//  ViewController.swift
//  TravelBuddy_Final_8996799
//
//  Created by user228293 on 8/16/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

