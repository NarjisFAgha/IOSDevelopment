//
//  TripTableViewCell.swift
//  TravelBuddy_Final_8996799
//
//  Created by user228293 on 8/18/24.
//

import UIKit

class TripTableViewCell: UITableViewCell {
    
    @IBOutlet weak var tripNameLabel: UILabel!
    
    @IBOutlet weak var destinationLabel: UILabel!
}

