//
//  ViewController.swift
//  Assingment1
//
//  Created by user228293 on 5/16/24.
//

import UIKit

class ViewController: UIViewController
{
    
    @IBOutlet weak var calculatorworkigs: UILabel!
    
    @IBOutlet weak var calculatorResults: UILabel!
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func AllClear(_ sender: UIButton) {
    }
    
    @IBAction func Percentage(_ sender: Any) {
    }
    
    @IBAction func Square(_ sender: Any) {
    }
    
    @IBAction func Division(_ sender: Any) {
    }
    
    @IBAction func Multiply(_ sender: Any) {
    }
    
    @IBAction func Subtract(_ sender: Any) {
    }
    
    
    @IBAction func Addition(_ sender: Any) {
    }
    
    @IBAction func Equals(_ sender: Any) {
    }
    
    @IBAction func Decimal_point(_ sender: Any) {
    }
    
    @IBAction func Zero(_ sender: Any) {
    }
    
    @IBAction func One(_ sender: Any) {
    }
    
    @IBAction func Two(_ sender: Any) {
    }
    
    @IBAction func Three(_ sender: Any) {
    }
    
    @IBAction func Four(_ sender: Any) {
    }
    
    @IBAction func Five(_ sender: Any) {
    }
    
    @IBAction func Six(_ sender: Any) {
    }
    
    @IBAction func Seven(_ sender: Any) {
    }
    
    @IBAction func Eight(_ sender: Any) {
    }
    
    @IBAction func Nine(_ sender: Any) {
    }
}

